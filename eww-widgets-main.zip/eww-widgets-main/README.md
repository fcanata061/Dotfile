<h1 align="center"> <a href="https://github.com/elkowar/eww"> EWW - Elkowar's Wacky Widgets <h1> </a>
<!-- ![eww](https://user-images.githubusercontent.com/72156551/153015496-6111b2c9-4f68-4999-a62e-b85273a926e0.gif) -->
<img src="https://github.com/saimoomedits/eww-widgets/blob/main/eww.gif"  alt="bar"/><br/></h3>

![SS](https://user-images.githubusercontent.com/72156551/154564705-ecd540bd-e8c5-4b03-8827-c76b2ef6eb08.png)

 # Old
![eww-again](https://user-images.githubusercontent.com/72156551/153015524-00e97b37-6af2-412b-92a2-bf092c2fc5ae.png)
  
# Credits
**[niraj998 - workspace script for eww](https://github.com/niraj998)**
