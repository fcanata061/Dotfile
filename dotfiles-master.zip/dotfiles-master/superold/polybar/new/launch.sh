#!/usr/bin/env bash

# Launch the bar
STYLE="default"

bash "$HOME"/.config/polybar/"$STYLE"/launch.sh
